// Runs at document_start — before any page JavaScript — so our listener is
// registered first in the capture phase.
//
// When the user right-clicks, we call stopImmediatePropagation() to prevent
// the site's own contextmenu handler (e.g. 500px's copyright overlay) from
// firing, while NOT calling preventDefault() so the browser's native context
// menu (including the extension's "Share image to Tumblr" item) still appears.
window.addEventListener('contextmenu', function (e) {
  e.stopImmediatePropagation();
}, true /* capture phase */);
